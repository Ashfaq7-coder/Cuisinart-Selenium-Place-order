package us_cuisinart;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import java.time.Duration;
import java.util.List;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.chrome.ChromeDriver;

public class Place_Order {

	public static void main(String[] args) {

		// 1. Launch Browser (Chrome)
		// ChromeDriver driver = new ChromeDriver();

		WebDriver driver = new ChromeDriver();

		// 2. Open URL
		// https://abaf-016.dx.commercecloud.salesforce.com/s/us-cuisinart-sfra/

		driver.get("https://abaf-016.dx.commercecloud.salesforce.com/s/us-cuisinart-sfra/");

		// Maximize browser and set timeout
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		// Close cookies pop-up
		// try {
		// WebElement acceptCookies =
		// driver.findElement(By.id("onetrust-close-btn-container"));
		// acceptCookies.click();

		// System.out.println("Cookies pop-up closed!");

		// } catch (Exception e) {

		// System.out.println("Cookies pop-up not found or already closed.");
		// }

		// driver.findElement(By.id("onetrust-close-btn-container")).click();

		driver.findElement(By.id("appliances")).click();
		driver.findElement(By.id("appliances_standmixers")).click();

		// Set Timeout

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		// driver.findElement(By.id("onetrust-close-btn-container")).click();

		WebElement product = driver.findElement(By.xpath("//button[@data-pid='PE-50']"));
		product.click();

		WebElement viewCartButton = driver.findElement(By.linkText("View Cart"));
		viewCartButton.click();

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		WebElement checkoutButton = driver.findElement(By.linkText("Checkout"));
		checkoutButton.click();

		WebElement guestemail = driver.findElement(By.id("email-guest"));
		guestemail.sendKeys("shaiktest1004@gmail.com");

		WebElement guestbutton = driver.findElement(By.className("submit-customer"));
		guestbutton.click();

		/*
		 * // Enter Address WebElement addressField =
		 * driver.findElement(By.id("shipping-address"));
		 * addressField.sendKeys("123 Main Street");
		 * 
		 * WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		 * 
		 * // Wait for Experian Suggestion Dropdown WebElement suggestion =
		 * wait.until(ExpectedConditions.visibilityOfElementLocated(
		 * By.xpath("//ul[@class='experian-suggestions']/li[1]")));
		 * 
		 * // Select the First Suggested Address suggestion.click();
		 */

		WebElement firstName = driver.findElement(By.id("shippingFirstNamedefault"));
		firstName.sendKeys("First User");

		WebElement LastName = driver.findElement(By.id("shippingLastNamedefault"));
		LastName.sendKeys("Last User");

		WebElement AddressField1 = driver.findElement(By.id("shippingAddressOnedefault"));
		AddressField1.sendKeys("678 Main St");
		
		/*// Wait for the Shipping Address form to appear
        WebElement addressField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("shippingAddressOnedefault")));
*/
       /* // Enter Address Line 1
        WebElement AddressField1.sendKeys("678 Main St");
*/
        // Wait for Experian suggestion to appear & select it
        /*WebElement experianSuggestion = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[contains(@class, 'experian-suggestion')]")));
        experianSuggestion.click();
        */
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        // Enter City
        WebElement cityField = driver.findElement(By.id("shippingAddressCitydefault"));
        cityField.sendKeys("Abercrombie");

        // Select State from Dropdown
        Select stateDropdown = new Select(driver.findElement(By.id("shippingAddressStatedefault")));
        stateDropdown.selectByVisibleText("North Dakota");

        // Enter ZIP Code
        WebElement zipField = driver.findElement(By.id("shippingAddressZIPdefault"));
        zipField.sendKeys("58001");
        
       // WebElement zipField = ((zipField) driver).click ();

        // Click Save/Continue Button
        WebElement continueButton = driver.findElement(By.id("shippingContinue"));
        continueButton.click();

        // Confirmation
        System.out.println("Shipping address added successfully!");

		/*
		 * } catch (Exception e) { System.out.println("❌ Error occurred: " +
		 * e.getMessage()); } finally { // Close the browser // driver.quit(); }
		 */


		/*
		 * List<WebElement> listitems = (List<WebElement>) driver
		 * .findElement(By.xpath("//*[@id=\"shippingAddressOnedefault\"]/li"));
		 * 
		 * System.out.println(listitems.size());
		 */
		/*
		 * driver.switchTo().frame("frame_id"); // Replace with actual iframe ID or
		 * index WebElement addressField =
		 * driver.findElement(By.id("shippingAddressOnedefault"));
		 */

		/*
		 * WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		 * WebElement shippingAddressDropdown =
		 * wait.until(ExpectedConditions.elementToBeClickable(By.id(
		 * "shippingStatedefault")));
		 * 
		 * Select select = new Select(shippingAddressDropdown);
		 * select.selectByVisibleText("Abercrombie");
		 * 
		 * 
		 * [li,
		 * WebElement stateDropdown = driver.findElement(By.id("shippingStatedefault"));
		 * 
		 */
		/*
		 * Select select = new Select(stateDropdown);
		 * select.selectByVisibleText("Kansas");
		 * 
		 * 
		 * /* WebElement Cityfield =
		 * driver.findElement(By.id("shippingAddressCitydefault"));
		 * Cityfield.sendKeys("Ashland");
		 * 
		 * WebElement Zipcodefield =
		 * driver.findElement(By.id("shippingZipCodedefault"));
		 * Zipcodefield.sendKeys("67831-3502");
		 */
		// WebElement Phonefield =
		// driver.findElement(By.id("shippingPhoneNumberdefault"));
		// Phonefield.sendKeys("0298897781");

	}

}
